// Package plumbing contains objects and methods to work on git
// internals
package plumbing
