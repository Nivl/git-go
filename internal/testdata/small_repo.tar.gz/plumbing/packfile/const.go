package packfile

// list of file extensions
const (
	ExtPackfile = ".pack"
	ExtIndex    = ".idx"
)
