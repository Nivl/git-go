// Package readutil contains helper methods to simplify reading operations
package readutil
