// Package git contains methods to deal with git internals
package git
